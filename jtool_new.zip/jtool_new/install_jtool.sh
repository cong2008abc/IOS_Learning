#set -e;
#cd  "$(mktemp -d)"
#curl -LO 'http://www.newosxbook.com/tools/jtool2.tgz'

#tar -x -f jtool2.tgz
#lipo jtool -thin arm64 -output jtool.x86_64
lipo jtool -thin arm64 -output jtool.arm64
#lipo disarm -thin x86_64 -output disarm.x86_64
sudo mkdir -p /usr/local/bin
#sudo cp jtool.x86_64 /usr/local/bin/jtool
sudo cp jtool.arm64 /usr/local/bin/jtool
sudo cp disarm /usr/local/bin/disarm